#!/bin/bash



cd 01-Density
bash run.sh
cd ..
cd 02-Wfn
bash run.sh
cd ..
cd 03-Wfnq
bash run.sh
cd ..
cd 04-Wfn_co
bash run.sh
cd ..
cd 11-epsilon
bash run.sh
cd ..
cd 12-sigma
bash run.sh
cd ..


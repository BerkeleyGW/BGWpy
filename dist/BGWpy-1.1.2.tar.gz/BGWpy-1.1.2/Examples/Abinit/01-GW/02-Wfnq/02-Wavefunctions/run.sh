#!/bin/bash


MPIRUN='mpirun -n 1 --npernode 1'
ABINIT='abinit'

ln -nfs ../../../01-Wfn/01-Density/out_data/odat_DEN input_data/idat_DEN

$MPIRUN $ABINIT < Si.files &> Si.log


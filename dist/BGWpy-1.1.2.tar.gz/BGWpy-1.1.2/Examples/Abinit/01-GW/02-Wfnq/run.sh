#!/bin/bash


MPIRUN='mpirun -n 1 --npernode 1'

cd 02-Wavefunctions
bash run.sh
cd ..
cd 02-Wavefunctions
bash abi2bgw.run.sh
cd ..


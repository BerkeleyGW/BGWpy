#!/bin/bash



cd 01-Wfn
bash run.sh
cd ..
cd 02-Wfnq
bash run.sh
cd ..
cd 03-Wfn_co
bash run.sh
cd ..
cd 11-Epsilon
bash run.sh
cd ..
cd 12-Sigma
bash run.sh
cd ..


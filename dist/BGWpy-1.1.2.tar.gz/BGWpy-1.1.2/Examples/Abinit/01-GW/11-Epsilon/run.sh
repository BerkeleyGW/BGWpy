#!/bin/bash


MPIRUN='mpirun -n 1 --npernode 1'
EPSILON='epsilon.cplx.x'
EPSILONOUT='epsilon.out'

ln -nfs ../01-Wfn/02-Wavefunctions/wfn.cplx WFN
ln -nfs ../02-Wfnq/02-Wavefunctions/wfn.cplx WFNq

$MPIRUN $EPSILON &> $EPSILONOUT


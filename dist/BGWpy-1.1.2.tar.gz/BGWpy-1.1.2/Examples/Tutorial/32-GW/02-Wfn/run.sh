#!/bin/bash


MPIRUN='mpirun -n 2 --npernode 2'

cd 02-Wavefunctions
bash run.sh
cd ..
cd 02-Wavefunctions
bash run-pw2bgw.sh
cd ..


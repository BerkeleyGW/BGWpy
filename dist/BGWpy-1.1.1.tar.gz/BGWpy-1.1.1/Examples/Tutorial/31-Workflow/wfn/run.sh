#!/bin/bash


MPIRUN='mpirun -n 8 --npernode 8'
PW='pw.x'
PWFLAGS=''

ln -nfs ../../density/GaAs.save/charge-density.dat GaAs.save/charge-density.dat

cp -f ../density/GaAs.save/data-file.xml GaAs.save/data-file.xml

$MPIRUN $PW $PWFLAGS -in wfn.in &> wfn.out


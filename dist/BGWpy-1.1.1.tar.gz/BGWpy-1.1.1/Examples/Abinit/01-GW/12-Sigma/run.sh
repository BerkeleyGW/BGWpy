#!/bin/bash


MPIRUN='mpirun -n 1 --npernode 1'
SIGMA='sigma.cplx.x'
SIGMAOUT='sigma.out'

ln -nfs ../03-Wfn_co/02-Wavefunctions/wfn.cplx WFN_inner
ln -nfs ../01-Wfn/02-Wavefunctions/rho.cplx RHO
ln -nfs ../01-Wfn/02-Wavefunctions/vxc.cplx VXC
ln -nfs ../11-Epsilon/eps0mat eps0mat
ln -nfs ../11-Epsilon/epsmat epsmat

$MPIRUN $SIGMA &> $SIGMAOUT


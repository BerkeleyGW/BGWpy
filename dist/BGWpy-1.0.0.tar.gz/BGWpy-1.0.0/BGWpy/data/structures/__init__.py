


#structures['GaAs'] = 'GaAs.json'

structures_files = [
    'GaAs.cif'
    'GaAs.json'
    'Si.cif'
    'Si.json'
    'write-GaAs-structure.py'
    'write-Si-structure.py'
    ]




